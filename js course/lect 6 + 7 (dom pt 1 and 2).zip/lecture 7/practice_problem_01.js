/*
practice problem 01:

Create a new button element. Give it a text "click me", background color of red and text color of white.
Insert the button as the first element inside the body tag.
*/

let newElmnt = document.createElement("button");
newElmnt.innerText = "click me!!";
newElmnt.style.color = "white";
newElmnt.style.backgroundColor = "red";
let bodyElmnt = document.querySelector("body");
bodyElmnt.append(newElmnt);
