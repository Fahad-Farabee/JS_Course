/* Creat a <p> tag in HTML, give it a class and some styling.
Now creat a new class in CSS and try to append this class to the <p> element.

Did you notice, how you overwrite the class name when you add a new one?
solve this problem using classlist.*/

let para = document.querySelector("p");
//para.setAttribute("class", "newContent");
//if i use setAttribute then class will be overwritten not appended.
//for this we will use class list.
//using this we add or remove classes together. kind of appending them
para.classList.add("newContent");