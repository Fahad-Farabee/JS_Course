//DOM manipulation pt 2
//attributes
//getAttribute()
let divElmnt = document.querySelector("div");
console.log(divElmnt);
let divId = divElmnt.getAttribute("id");//divId now have the value of the id attribute which is "div-Id"
console.log(divId);
//setAttribute()
let paraElmnt = document.querySelector("p");
paraElmnt.setAttribute("class", "new_para_class");//set does not return a new element.
console.log(paraElmnt.getAttribute("class")); 

//Insert Elements:
let newElmnt = document.createElement("button");
newElmnt.innerText = "beat me!!!";
//divElmnt.append(newElmnt);//adds at the end of node[inside]
//divElmnt.prepend(newElmnt);//add at the start of node[inside]
//divElmnt.before(newElmnt);//adds before the node[outside]
divElmnt.after(newElmnt);//adds after the node[outside]
//lets do something ourself:
//i will add a new heading just before my div like : "Hello i am a div heading from JS";
//but we will do it in just a line.
let newHeading = document.createElement("h1");//creating an element
newHeading.innerText="Hello i am a new div heading from JS";
document.querySelector("div").before(newHeading);//adding an element.

//Delete Elements:
let rmvItem = document.querySelector("h1");
rmvItem.remove();



