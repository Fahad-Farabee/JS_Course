/* //ul
let newElmnt = document.createElement("li");
newElmnt.innerText = "banana";

let fruitList = document.querySelector("ul");
fruitList.appendChild(newElmnt); */

/* //body 
let newElmnt = document.createElement("p");
newElmnt.innerText = "banana";

let bodyElmnt = document.querySelector("body");
bodyElmnt.appendChild(newElmnt); */

/*//div 
let newElmnt = document.createElement("button");
newElmnt.innerText = "Button";

let divElmnt = document.querySelector("div");
divElmnt.appendChild(newElmnt); */

//removing child
//if we know the parent and child node.
/* let parentNode = document.querySelector("div");
let childNode = document.querySelector("p");
let rmvdNode = parentNode.removeChild(childNode); */

//if we do not know the parent or child node.
/* let node = document.querySelector("h2");
if(node.parentNode){
    node.parentNode.removeChild(node);
} */

//if we wanna remove all the child of a node.
/* let node = document.querySelector("div");
while(node.firstChild){
    node.removeChild(node.firstChild);
} */